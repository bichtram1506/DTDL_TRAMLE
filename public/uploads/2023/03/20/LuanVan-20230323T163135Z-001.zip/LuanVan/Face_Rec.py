from arcface import ArcFace

def Arc_Face_embed(face):
    face_rec=ArcFace.ArcFace()
    t=[]
    if (len(face)>10):
        try:
            t=face_rec.calc_emb(face)
        except:
            t=[]
    return t