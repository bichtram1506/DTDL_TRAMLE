import pymysql
import datetime
def themnv(ho,chulot,ten,i,oi):
  connection = pymysql.connect(host="localhost", user="root", passwd="", database="htloc")
  cursor = connection.cursor()
  insert = "INSERT INTO hs_hr_employee(emp_number,employee_id,emp_lastname,emp_firstname,emp_middle_name," \
           " emp_smoker) VALUES("+i+",'"+oi+"','"+ho+"','"+ten+"','"+chulot+"',0);"
  cursor.execute(insert)
  connection.commit()
  connection.close()

hos=["Ho","Nguyen","Le","Phan","Ha","Duong","Tran","Luong","Vo","Huynh"]
chulots=["Van","Tan","Phan","Thi","Thi My","Thi Ai","Mong","Ngoc","Manh","Phi"]
tens=["Linh","Phung","Nguyen","Tien","Thai","My","Kien","Y","Manh","Nhi"]

# i=2
# oi="000"+str(i)
# for ho in hos:
#     for chulot in chulots:
#         for ten in tens:
#             themnv(ho,chulot,ten,str(i),oi)
#             print(i)
#             i = i + 1
#             oi="000"+str(i)

def themfile(i,j):
  connection = pymysql.connect(host="localhost", user="root", passwd="", database="htloc")
  cursor = connection.cursor()
  dt2 = datetime.datetime.now()
  fi="LOAD_FILE('/Users/hotanloc/Dataset/"+i+"/"+j+".png')"
  insert = "INSERT INTO hs_hr_emp_attachment(emp_number,eattach_id,eattach_filename,eattach_size,eattach_attachment,eattach_type,"\
          "screen,attached_by,attached_by_name,attached_time) VALUES("+i+","+j+",'loc1.jpg',962700,"+fi+",'image/jpeg',"\
          "'personal',1,'hotanloc','"+str(dt2)+"');"
  cursor.execute(insert)
  connection.commit()
  connection.close()
for i in range(2,1001):
    for j in range(0,3):
        themfile(str(i),str(j))